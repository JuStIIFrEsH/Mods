# Changelog

## 2.1.4

- Smoothed stacked chest visuals by keeping the top steel bands clear of the lid and neighboring boxes.

## 2.1.3

- Refined structure build-menu icons and enlarged the Dedicated Storage Box's item and count display, with compact labels for large counts.

## 2.1.1

- Rebuilt the Dedicated Storage Box with custom wood and iron visuals, a cleaner lock rune, and readable stored-item counts.

## 2.1.0

- Updated Hugin's Reliquary with its custom column visual, detailed raven ornaments, glowing runes, and raised Hugin perch; synchronized the in-game version.

## 2.0.0

- Added Munin's Waystation, a 16-slot wilderness cache that routes items to a linked Hugin's Reliquary, with corrected inventory slots, StoreAndCraft interactions, and custom chest visuals. Hugin's Reliquary also sorts nearby dropped items into storage.

## 1.0.2

- Updated the package icon.

## 1.0.1

- Renamed legacy internal identifiers to JuStIIFrEsH branding while preserving existing placed storage boxes and contents.

## 1.0.0

- First stable FreshDedicatedStorage release.
- Added optional storage-companion linking and linked station auto-pull support.

## 0.4.40

- Added feedback and donation links to the package README.

## 0.4.39

- Added linked station feeding for Dedicated Storage Boxes when the optional storage companion is installed.

## 0.4.38

- Removed the unintended six-slot FreshDedicatedStorage chest. The mod now registers only Dedicated Storage Boxes and Hugin's Reliquary.
- Renamed the plugin assembly to `FreshStorage.dll`.

## 0.4.37

- Added the bug-report link to `/freshstorage` help.
- Corrected the production model-asset reference used by item-icon placement.

## 0.4.36

- Initial public release of FreshDedicatedStorage.
