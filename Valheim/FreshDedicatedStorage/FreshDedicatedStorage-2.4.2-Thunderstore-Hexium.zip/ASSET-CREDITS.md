# Asset credits

FreshDedicatedStorage currently ships original custom geometry for the Dedicated Storage Box, Hugin's Reliquary, and Munin's Waystation.

The Dedicated Storage Box source mesh is generated from `Assets/DedicatedStorageChest/build_dedicated_storage_chest.py` and is maintained as project-owned geometry.
