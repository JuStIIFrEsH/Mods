# Changelog

## 1.0.1

- Renamed legacy internal identifiers to JuStIIFrEsH branding while preserving existing placed storage boxes and contents.

## 1.0.0

- First stable FreshDedicatedStorage release.
- Added optional storage-companion linking and linked station auto-pull support.

## 0.4.40

- Added feedback and donation links to the package README.

## 0.4.39

- Added linked station feeding for Dedicated Storage Boxes when the optional storage companion is installed.

## 0.4.38

- Removed the unintended six-slot FreshDedicatedStorage chest. The mod now registers only Dedicated Storage Boxes and Hugin's Reliquary.
- Renamed the plugin assembly to `FreshStorage.dll`.

## 0.4.37

- Added the bug-report link to `/freshstorage` help.
- Corrected the production model-asset reference used by item-icon placement.

## 0.4.36

- Initial public release of FreshDedicatedStorage.
