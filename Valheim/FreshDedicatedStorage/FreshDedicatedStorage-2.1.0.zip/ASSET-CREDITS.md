# Asset credits

The Dedicated Storage Box embeds a source geometry file converted from a CC0 asset by Quaternius on Poly Pizza. The source textures are not redistributed; the mod creates its own runtime material palette. Hugin's Reliquary and Munin's Waystation use original custom structure meshes.

| Use | Asset | Source | License |
| --- | --- | --- | --- |
| Dedicated Storage Box | Wood Chest | https://poly.pizza/m/YyAS0OHd4i | CC0 1.0 Universal |

CC0 legal text: https://creativecommons.org/publicdomain/zero/1.0/legalcode
