# FreshCommands

A lightweight standalone BepInEx mod that adds useful console and chat commands and related structures to Valheim.

**Author:** JuStIIFrEsH

## Links

- [Valheim Mods](https://justiifresh.com/valheim/)
- [Report a Bug](https://justiifresh.com/valheim/bug/)
- [Send Feedback](https://justiifresh.com/valheim/feedback/)
- [Donate](https://ko-fi.com/justiifresh)

## Requirements

- BepInEx 5
- Jotunn 2.30.0


## Commands

### In-game chat commands

- `/corpse tp` — teleports the character to their most recently created tombstone.
- `/corpse recover` — performs the normal tombstone interaction, collecting its contents when they fit or opening the standard inventory when they do not.
- `/tp home` — teleports the character to their current spawn point.
- `/set <name>` — saves the current player position as a named location and adds a circle marker to the map. For example, `/set plains2` followed by `/tp plains2`.
- `/set <name> <x> <z>` — saves supplied X/Z coordinates as a named location. For example, `/set crypt1 1250 -800`.
- `/delete <name>` — permanently removes a saved location from the world save.
- `/tp <name>` — teleports to a saved location. `/tp` by itself lists all saved locations and their coordinates.
- `/freshcommands` — lists every available FreshCommands command.

### Console commands

- `corpse tp` — teleports the character to their most recently created tombstone.
- `corpse recover` — performs the normal tombstone interaction, collecting its contents when they fit or opening the standard inventory when they do not.
- `tp home` — teleports the character to their current spawn point.
- `set <name>` — saves the current player position as a named location and adds a circle marker to the map. For example, `set plains2` followed by `tp plains2`.
- `set <name> <x> <z>` — saves supplied X/Z coordinates as a named location. For example, `set crypt1 1250 -800`.
- `delete <name>` — permanently removes a saved location from the world save.
- `tp <name>` — teleports to a saved location. `tp` by itself lists all saved locations and their coordinates.
- `freshcommands` — lists every available FreshCommands command.

## Map tools

With the main map open, cursor coordinates appear in the upper-left corner. Creating a saved location with `/set` places a portal marker on the map; Ctrl+Shift+Click the marker to travel to that saved location.

## Placeable structures

FreshCommands also adds three custom teleportation structures.

### Corpsecaller's Effigy

<img src="https://raw.githubusercontent.com/JuStIIFrEsH/Mods/main/Valheim/FreshCommands/previews/corpsecallers-effigy.jpg" alt="Corpsecaller's Effigy" width="25%" />

A wall-mounted skull for reaching your most recent corpse without opening the console.
Its cyan flames appear for each player while that player has a physical tombstone to retrieve.

- Requires a nearby workbench, 8 Bone Fragments, 4 Wood, and 5 Resin.
- Press E to recover your corpse inventory without moving your character.
- Press Shift+E to teleport to your most recent corpse using Valheim's normal loading transition.

### Wayfarer's Reach

<img src="https://raw.githubusercontent.com/JuStIIFrEsH/Mods/main/Valheim/FreshCommands/previews/wayfarers-reach.jpg" alt="Wayfarer's Reach" width="25%" />

An outward teleportation device for your base.

- Requires a nearby workbench, 10 Stone, 1 Surtling Core, and 1 Greydwarf Eye.
- Press E to open a menu containing your saved locations.

### Wayfarer's Oathstone

<img src="https://raw.githubusercontent.com/JuStIIFrEsH/Mods/main/Valheim/FreshCommands/previews/wayfarers-oathstone.jpg" alt="Wayfarer's Oathstone" width="25%" />

A stone shrine for returning to your current spawn point. Two fractured spires frame a hovering Greydwarf Eye with a soft blue glow.

- Can be built away from a workbench with 10 Stone and 1 Greydwarf Eye.
- Press E to teleport to your current spawn point, equivalent to `tp home`.

## Notes

- Saved locations are shared by everyone on the same world and persist in that world's database save data.
- Commands work in single-player and for the hosting player.
- Dedicated-server and remote-client command routing is not included.
