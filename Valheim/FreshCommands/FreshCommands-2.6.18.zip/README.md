# FreshCommands

A lightweight standalone BepInEx mod that adds useful console and chat commands to Valheim.

**Author:** JuStIIFrEsH

## Links

- [Valheim Mods](https://justiifresh.com/valheim/)
- [Report a Bug](https://justiifresh.com/valheim/bug/)
- [Send Feedback](https://justiifresh.com/valheim/feedback/)
- [Donate](https://ko-fi.com/justiifresh)
- [Thunderstore](https://thunderstore.io/c/valheim/p/JuStIIFrEsH/FreshCommands/)

## Requirements

- BepInEx 5
- Jotunn 2.30.0

## Installation

Install FreshCommands through Thunderstore, or copy `FreshCommands.dll` into a folder under `BepInEx/plugins` and launch Valheim.

Dev commands do not need to be enabled.

## Commands

### In-game chat commands

- `/corpse tp` — teleports the character to their most recently created tombstone.
- `/corpse recover` — performs the normal tombstone interaction, collecting its contents when they fit or opening the standard inventory when they do not.
- `/tp home` — teleports the character to their current spawn point.
- `/set <name>` — saves the current player position as a named location. For example, `/set plains2` followed by `/tp plains2`.
- `/set <name> <x> <z>` — saves supplied X/Z coordinates as a named location. For example, `/set crypt1 1250 -800`.
- `/delete <name>` — permanently removes a saved location from the world save.
- `/tp <name>` — teleports to a saved location. `/tp` by itself lists all saved locations and their coordinates.
- `/freshcommands` — lists every available FreshCommands command.

### Console commands

- `corpse tp` — teleports the character to their most recently created tombstone.
- `corpse recover` — performs the normal tombstone interaction, collecting its contents when they fit or opening the standard inventory when they do not.
- `tp home` — teleports the character to their current spawn point.
- `set <name>` — saves the current player position as a named location. For example, `set plains2` followed by `tp plains2`.
- `set <name> <x> <z>` — saves supplied X/Z coordinates as a named location. For example, `set crypt1 1250 -800`.
- `delete <name>` — permanently removes a saved location from the world save.
- `tp <name>` — teleports to a saved location. `tp` by itself lists all saved locations and their coordinates.
- `freshcommands` — lists every available FreshCommands command.

## Placeable structures

FreshCommands also adds three new teleportation structures.

### Corpsecaller's Effigy

A wall-mounted skull for reaching your most recent corpse without opening the console.

- Requires a nearby workbench, 8 Bone Fragments, 4 Wood, and 5 Resin.
- Press E to recover your corpse inventory without moving your character.
- Press Shift+E to teleport to your most recent corpse using Valheim's normal loading transition.

### Wayfarer's Oathstone

A small wilderness landmark for returning to your current spawn point.

- Can be built away from a workbench with 10 Stone and 1 Greydwarf Eye.
- Press E to teleport to your current spawn point, equivalent to `tp home`.

### Wayfarer's Reach

A floor- or ground-placeable outward teleportation device for your base.

- Requires a nearby workbench, 10 Stone, 1 Surtling Core, and 1 Greydwarf Eye.
- Press E to open a menu containing your saved locations.
- Choose a location to teleport there using Valheim's normal loading transition.
- Approach within 3 meters to awaken its blue portal fire and vanilla portal sounds. Moving away leaves a silent black sphere with rolling blue energy waves.

## Notes

- Saved locations are shared by everyone on the same world and persist in that world's database save data.
- Commands work in single-player and for the hosting player.
- Dedicated-server and remote-client command routing is not included.
