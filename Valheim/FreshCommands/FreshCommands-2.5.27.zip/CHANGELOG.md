# Changelog

Important changes to FreshCommands are recorded here.

## 2.5.27

- Cleared the Oathstone prefab's inherited workbench reference.

## 2.5.26

- Removed the Oathstone's inherited workbench requirement so it can be placed anywhere.
- Moved the Effigy skull 5 cm deeper toward its wall mount.

## 2.5.25

- Removed the vanilla trophy's forward item offset so the Effigy skull anchors directly to its wall mount.

## 2.5.24

- Moved the correctly oriented Effigy skull 40 cm back toward its wall mount.

## 2.5.23

- Applied the original item stand's hidden attachment transform before mounting the Effigy skull, matching Valheim's normal wall-trophy orientation.

## 2.5.22

- Raised and enlarged the Oathstone eye again and restored its particle effects.
- Corrected the Effigy skull by applying Valheim's built-in vertical item-stand trophy orientation.

## 2.5.21

- Raised the Oathstone eye 20 cm and increased its size by 50%.
- Enforced the Effigy skull's outward wall-mount orientation after visual initialization.

## 2.5.20

- Raised and centered the Oathstone eye between the shards and increased its size.
- Removed inherited item scripts from decorative visuals and isolated the Effigy's mounting rotation from the trophy hierarchy.

## 2.5.19

- Removed the Oathstone rune marker and raised and enlarged its bound eye between the stone shards.
- Corrected the Effigy skull to the opposite wall-facing orientation.

## 2.5.18

- Reworked Wayfarer's Runestone as Wayfarer's Oathstone: split stone shards, a bound eye, and a restrained gold rune.
- Rotated Corpsecaller's Effigy so the skull face points away from the wall.

## 2.5.17

- Corrected Corpsecaller's Effigy wall orientation and removed custom structure particle effects.
- Refined Wayfarer's Runestone into a stone slab with an inset eye rune.
- Restored visible placement ghosts for both custom structures.

## 2.5.16

- Reworked Wayfarer's Cairn as Wayfarer's Runestone: a standing stone with a glowing Greydwarf Eye.

## 2.5.15

- Restored Corpsecaller's Effigy registration by using Valheim's valid `itemstand` wall-piece prefab.

## 2.5.14

- Made Corpsecaller's Effigy inherit normal wall placement from the vanilla sign.
- Rebuilt Wayfarer's Cairn from Valheim's stone models and repaired its destruction references so deconstruction removes it cleanly.

## 2.5.13

- Corrected the Effigy and Cairn being marked as demolition tools, which hid their normal build buttons and prevented placement previews. They remain deconstructible.
- Removed the unsuccessful build-menu availability overrides; structures use normal material discovery again.

## 2.5.12

- Made Hammer registration deterministic by injecting the registered Effigy and Cairn prefabs directly into its Furniture list.

## 2.5.11

- Restored the normal Jotunn registration flow used by FreshDedicatedStorage and fixed the Hammer menu's final availability list without altering character discoveries.

## 2.5.10

- Fixed the Effigy and Cairn being filtered out by the Hammer's own availability check.

## 2.5.9

- Changed Corpsecaller's Effigy to require normal Wood instead of Fine Wood.
- Corrected custom-structure availability matching so the Effigy and Cairn stay visible in the Hammer build menu.

## 2.5.8

- Made the Effigy and Cairn visible in Hammer > Furniture without unlocking their build materials or unrelated recipes.

## 2.5.7

- Ensured the build materials for the Effigy and Cairn are discovered so both pieces remain visible in Hammer > Furniture.

## 2.5.6

- Made the Corpsecaller's Effigy and Wayfarer's Cairn immediately available in Hammer > Furniture for the local player.

## 2.5.5

- Changed the Wayfarer's Cairn requirement from Surtling Core to Greydwarf Eye.

## 2.5.4

- Fixed the structure tooltip key prompts, scale, materials, and normal removal behavior.
- Changed the Corpsecaller's Effigy material requirement from Skeleton Trophy to Bone Fragments so it is available earlier.

## 2.5.3

- Fixed the Corpsecaller's Effigy and Wayfarer's Cairn registrations by using valid vanilla building-piece bases.

## 2.5.1

- Renamed the Corpsecaller's Totem to Corpsecaller's Effigy.

## 2.5.0

- Added the wall-mountable Corpsecaller's Effigy: E recovers your most recent corpse and Shift+E teleports to it.
- Added the wilderness-placeable Wayfarer's Cairn for returning to your current spawn point.
- Added Jotunn as a required dependency for the new placeable structures.

## 2.4.21

- Added feedback and donation links to the package README.

## 2.4.20

- Updated `/freshcommands` help with the Valheim feedback and bug-report page.

## 2.4.19

- Added the bug-report link to `/freshcommands` help.

## 2.4.18

- Added the initial changelog.
- Startup help now opens the local chat panel for the normal 3-second chat display period.

## 2.4.14

- Added the Valheim-inspired teleport portal package icon.

## 2.4.3

- Changed `corpse recover` to retrieve tombstone inventory without moving the player.

## Earlier releases

- Added persistent named teleport locations with `set`, `tp`, and `delete` commands.
- Added chat command support and the `/freshcommands` help listing.
