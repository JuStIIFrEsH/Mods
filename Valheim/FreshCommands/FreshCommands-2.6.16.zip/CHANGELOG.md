# Changelog

Important changes to FreshCommands are recorded here.

## 2.6.16

- Added Wayfarer's Reach, a base-placeable outward teleportation device with a saved-location destination menu, animated dark void, rolling blue energy, and proximity-activated portal fire and audio.

## 2.5.29

- Added the wall-mountable Corpsecaller's Effigy: E recovers your most recent corpse and Shift+E teleports to it.
- Added the wilderness-placeable Wayfarer's Oathstone: E returns to your current spawn point.
- Added Jotunn as a required dependency for the new placeable structures.

## 2.4.20

- Updated `/freshcommands` help with the Valheim feedback and bug-report page.

## 2.4.19

- Added the bug-report link to `/freshcommands` help.

## 2.4.18

- Added the initial changelog.
- Startup help now opens the local chat panel for the normal 3-second chat display period.

## 2.4.14

- Added the Valheim-inspired teleport portal package icon.

## 2.4.3

- Changed `corpse recover` to retrieve tombstone inventory without moving the player.

## Earlier releases

- Added persistent named teleport locations with `set`, `tp`, and `delete` commands.
- Added chat command support and the `/freshcommands` help listing.
