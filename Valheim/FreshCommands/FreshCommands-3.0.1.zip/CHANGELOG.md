# Changelog

Important changes to FreshCommands are recorded here.

## 3.0.1

- Added map-marker teleporting
- Improved saved-location persistence; refreshed portal visuals, map readability, and structure previews.

## 2.6.35

- Updated cosmetics for Wayfarer's Reach and Wayfarer's Oathstone.

## 2.6.21

- Added Wayfarer's Reach, an outward teleportation device that allows teleportation to your saved locations.

## 2.5.29

- Added the wall-mountable Corpsecaller's Effigy: E recovers your most recent corpse and Shift+E teleports to it.
- Added the wilderness-placeable Wayfarer's Oathstone: E returns to your current spawn point.
- Added Jotunn as a required dependency for the new placeable structures.

## 2.4.20

- Updated `/freshcommands` help with the Valheim feedback and bug-report page.

## 2.4.19

- Added the bug-report link to `/freshcommands` help.

## 2.4.18

- Added the initial changelog.
- Startup help now opens the local chat panel for the normal 3-second chat display period.

## 2.4.14

- Added the Valheim-inspired teleport portal package icon.

## 2.4.3

- Changed `corpse recover` to retrieve tombstone inventory without moving the player.

## Earlier releases

- Added persistent named teleport locations with `set`, `tp`, and `delete` commands.
- Added chat command support and the `/freshcommands` help listing.
