# Changelog

Important changes to FreshCommands are recorded here.

## 2.6.34

- Updated the package description.

## 2.6.33

- Made the Oathstone eye rotate continuously and softened Reach's energy into overlapping mist clouds.
- Kept the structure teleport palette until the native transition is fully hidden.

## 2.6.32

- Fixed frozen Reach wisps on placed structures and increased their swirling motion.
- Reduced Oathstone size by 25%, strengthened eye and rune glow, and added gently randomized eye rotation.

## 2.6.31

- Recolored the seven native rotating teleport layers for structure travel, retaining the game's animation and fade.
- Replaced Reach's solid passive sphere with moving storm clouds and irregular blue energy wisps.
- Rebuilt Oathstone uprights as fractured shards with varied runes and the original Greydwarf Eye visual.

## 2.6.30

- Reworked Wayfarer's Reach's passive void into a smaller storm core surrounded by soft, layered blue-violet mist.
- Applied structure teleport artwork at the final UI render stage so it cannot be overwritten by Valheim's loading screen.

## 2.6.29

- Removed Wayfarer's Reach's active portal effects from its build-menu icon and synchronized the structure teleport artwork to Valheim's native animation.

## 2.6.28

- Made structure teleports recolor Valheim's native loading animation instead of overlaying a competing transition.

## 2.6.27

- Hid Wayfarer's Reach's approach-only flames from its build-piece preview.

## 2.6.26

- Reworked Wayfarer's Reach's idle void into a slow-moving indigo and violet storm sphere with visible cloud banks and wisps.

## 2.6.25

- Added a structure-only black, purple, and blue variant of Valheim's teleport transition using recolored copies of its original seven frames.

## 2.6.24

- Fixed the Oathstone eye visual on Valheim builds whose item meshes cannot be read at runtime.

## 2.6.23

- Rebuilt Wayfarer's Oathstone as a compact stone shrine with two fractured spires and a hovering Greydwarf Eye.

## 2.6.22

- Restored Wayfarer's Reach's large active blue flames.

## 2.6.21

- Added Wayfarer's Reach, an outward teleportation device that allows teleportation to your saved locations.

## 2.5.29

- Added the wall-mountable Corpsecaller's Effigy: E recovers your most recent corpse and Shift+E teleports to it.
- Added the wilderness-placeable Wayfarer's Oathstone: E returns to your current spawn point.
- Added Jotunn as a required dependency for the new placeable structures.

## 2.4.20

- Updated `/freshcommands` help with the Valheim feedback and bug-report page.

## 2.4.19

- Added the bug-report link to `/freshcommands` help.

## 2.4.18

- Added the initial changelog.
- Startup help now opens the local chat panel for the normal 3-second chat display period.

## 2.4.14

- Added the Valheim-inspired teleport portal package icon.

## 2.4.3

- Changed `corpse recover` to retrieve tombstone inventory without moving the player.

## Earlier releases

- Added persistent named teleport locations with `set`, `tp`, and `delete` commands.
- Added chat command support and the `/freshcommands` help listing.
