# Changelog

Important changes to FreshCommands are recorded here.

## 2.4.21

- Added feedback and donation links to the package README.

## 2.4.20

- Updated `/freshcommands` help with the Valheim feedback and bug-report page.

## 2.4.19

- Added the bug-report link to `/freshcommands` help.

## 2.4.18

- Added the initial changelog.
- Startup help now opens the local chat panel for the normal 3-second chat display period.

## 2.4.14

- Added the Valheim-inspired teleport portal package icon.

## 2.4.3

- Changed `corpse recover` to retrieve tombstone inventory without moving the player.

## Earlier releases

- Added persistent named teleport locations with `set`, `tp`, and `delete` commands.
- Added chat command support and the `/freshcommands` help listing.
